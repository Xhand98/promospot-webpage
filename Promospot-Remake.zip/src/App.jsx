import Routing from './root/Routes'
import './App.css'
function App() {

  return (
    <>
    <Routing />
    </>
  )
}

export default App

