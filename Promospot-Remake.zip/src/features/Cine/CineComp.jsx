import React from 'react'

const CineComp = () => {
    return(
        <div></div>
    )
}